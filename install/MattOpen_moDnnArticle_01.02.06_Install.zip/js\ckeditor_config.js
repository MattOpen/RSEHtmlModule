/**
 * DO NOT MODIFY THIS FILE
 */

 
CKEDITOR.editorConfig = function( config )
{
	config.toolbar = 'Medium';
    //config.maximizedToolbar = 'Full';
    config.allowedContent = true;   //show an allow javascript code in editor
	extraAllowedContent: 'section article header nav aside[lang,foo]'
    //config.extraPlugins = 'mathjax,qrcodes,oembed,syntaxhighlight';     //load additional plugins - must be installed before
    config.extraPlugins = 'syntaxhighlight,stylesheetparser';     //load additional plugins - must be installed before
    config.height = '300px';
	// ALLOW <i></i>
	config.protectedSource.push(/<i[^>]*><\/i>/g);
	config.protectedSource.push(/<a[^>]*><\/a>/g);
	//config.contentsCss = ['/DesktopModules/MattOpen/moDnnArticle/css/bootstrap.min.css', '/Portals/5/skins/expondeflex/css/custom.css'];
	config.contentsCss = ['/DesktopModules/MattOpen/moDnnArticle/css/bootstrap.min.css', SkinPath+'skin.css'];

 
	config.toolbar_Full =
	[
	{ name: 'document', items : [ 'Source','-','Save','NewPage','DocProps','Preview','Print','-','Templates' ] },
	{ name: 'clipboard', items : [ 'Cut','Copy','Paste','PasteText','PasteFromWord','-','Undo','Redo' ] },
	{ name: 'editing', items : [ 'Find','Replace','-','SelectAll','-','SpellChecker', 'Scayt' ] },
	{ name: 'forms', items : [ 'Form', 'Checkbox', 'Radio', 'TextField', 'Textarea', 'Select', 'Button', 'ImageButton', 
        'HiddenField' ] },
    { name: 'insert', items : [ 'Image','Flash','Table','HorizontalRule','Smiley','SpecialChar','PageBreak','Iframe'] },
	{ name: 'basicstyles', items : [ 'Bold','Italic','Underline','Strike','Subscript','Superscript','-','RemoveFormat' ] },
	{ name: 'paragraph', items : [ 'NumberedList','BulletedList','-','Outdent','Indent','-','Blockquote','CreateDiv',
	'-','JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock','-','BidiLtr','BidiRtl' ] },
	{ name: 'links', items : [ 'Link','Unlink','Anchor' ] },
	'/',
	{ name: 'styles', items : [ 'Styles','Format','Font','FontSize' ] },
	{ name: 'colors', items : [ 'TextColor','BGColor' ] },
	{ name: 'tools', items : [ 'Maximize', 'ShowBlocks','-','Mathjax','oembed','qrcodes','syntaxhighlight','-','About' ] }
	];
	
	config.toolbar_Medium =
    [
        { name: 'document', items : [ 'Source','-','DocProps','Preview','Print','-','Templates' ] },
        { name: 'clipboard', items : [ 'Cut','Copy','Paste','PasteText','PasteFromWord','-','Undo','Redo' ] },
        { name: 'editing', items : [ 'Find','Replace','-','SelectAll','-','SpellChecker', 'Scayt' ] },
		{ name: 'forms', items : [ 'Form', 'Checkbox', 'Radio', 'TextField', 'Textarea', 'Select', 'Button', 'ImageButton', 
        'HiddenField' ] },
        { name: 'insert', items : [ 'Image','Table','HorizontalRule','Smiley','SpecialChar','PageBreak','Iframe' ] },
        '/',
        { name: 'basicstyles', items : [ 'Bold','Italic','Underline','Strike','Subscript','Superscript','-','RemoveFormat' ] },
        { name: 'paragraph', items : [ 'NumberedList','BulletedList','-','Outdent','Indent','-','Blockquote','CreateDiv',
            '-','JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock','-','BidiLtr','BidiRtl' ] },
        { name: 'links', items : [ 'Link','Unlink','Anchor' ] },
        '/',
        { name: 'styles', items : [ 'Styles','Format','Font','FontSize' ] },
        { name: 'colors', items : [ 'TextColor','BGColor' ] },
        //{ name: 'tools', items : [ 'Maximize', 'ShowBlocks','-','Mathjax','oembed','qrcodes','syntaxhighlight','-','About' ] }
        { name: 'tools', items : [ 'Maximize', 'ShowBlocks','-','syntaxhighlight','-','About' ] }
    ];
	
	config.toolbar_MediumBasic =
    [
        { name: 'clipboard', items : [ 'Source','Cut','Copy','Paste'] },
        { name: 'basicstyles', items : [ 'Bold','Italic','Underline','Strike','Subscript','Superscript','-','RemoveFormat' ] },
        { name: 'paragraph', items : [ 'NumberedList','BulletedList','-','CreateDiv',
            '-','JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock' ] },
        { name: 'links', items : [ 'Link','Unlink','Anchor' ] },
        '/',
        { name: 'styles', items : [ 'Styles','Format','Font','FontSize' ] },
        { name: 'colors', items : [ 'TextColor','BGColor' ] },
        { name: 'tools', items : [ 'Maximize', 'ShowBlocks','-','About' ] }
    ];
	
	config.toolbar_Basic =
	[
	['Bold', 'Italic', '-', 'NumberedList', 'BulletedList', '-', 'Link', 'Unlink','-','About']
	];
	
	
};
